Testing
=======

Contributions to this repository will only be accepted if all tests pass successfully:

* PHP syntax/lint checks
* Unit tests: [PHPUnit](https://phpunit.de/)
* Coding standard-checks: [PHP_CodeSniffer](https://github.com/squizlabs/PHP_CodeSniffer/wiki)
